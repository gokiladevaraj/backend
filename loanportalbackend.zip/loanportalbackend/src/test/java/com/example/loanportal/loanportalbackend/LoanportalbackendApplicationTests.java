package com.example.loanportal.loanportalbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanportalbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
