package com.example.loanportal.loanportalbackend.repository;

import com.example.loanportal.loanportalbackend.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    // Find a student by email (used for login)
    Optional<Student> findByEmail(String email);
}
