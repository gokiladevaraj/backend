package com.example.loanportal.loanportalbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanportalbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanportalbackendApplication.class, args);
	}

}
