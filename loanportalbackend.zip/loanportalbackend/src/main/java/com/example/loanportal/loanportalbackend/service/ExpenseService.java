package com.example.loanportal.loanportalbackend.service;

import com.example.loanportal.loanportalbackend.dto.ExpenseRequest;
import com.example.loanportal.loanportalbackend.model.Expense;
import com.example.loanportal.loanportalbackend.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    // Add a new expense for a student
    public Expense addExpense(ExpenseRequest req) {
        Expense expense = new Expense();
        expense.setStudentId(req.getStudentId());
        expense.setCategory(req.getCategory());
        expense.setAmount(req.getAmount());
        expense.setDescription(req.getDescription());
        expense.setDate(req.getDate());
        return expenseRepository.save(expense);
    }

    // Get all expenses of a student
    public List<Expense> getExpenses(Long studentId) {
        return expenseRepository.findByStudentId(studentId);
    }
 // Get expense by ID
    public Expense getExpenseById(Long id) {
        return expenseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Expense not found with id: " + id));
    }

    // Update expense
    public Expense updateExpense(Long id, ExpenseRequest request) {
        Expense expense = getExpenseById(id);
        expense.setCategory(request.getCategory());
        expense.setAmount(request.getAmount());
        expense.setDate(request.getDate());
        expense.setDescription(request.getDescription());
        return expenseRepository.save(expense);
    }

    // Delete expense
    public void deleteExpense(Long id) {
        Expense expense = getExpenseById(id);
        expenseRepository.delete(expense);
    }
}
