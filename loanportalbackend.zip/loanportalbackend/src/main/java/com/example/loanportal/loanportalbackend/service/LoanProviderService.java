package com.example.loanportal.loanportalbackend.service;

import com.example.loanportal.loanportalbackend.model.LoanProvider;
import com.example.loanportal.loanportalbackend.repository.LoanProviderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanProviderService {

    @Autowired
    private LoanProviderRepository loanProviderRepository;

    // Add a new loan provider / bank
    public LoanProvider addProvider(LoanProvider provider) {
        return loanProviderRepository.save(provider);
    }

    // Get list of all loan providers
    public List<LoanProvider> getAllProviders() {
        return loanProviderRepository.findAll();
    }
}
