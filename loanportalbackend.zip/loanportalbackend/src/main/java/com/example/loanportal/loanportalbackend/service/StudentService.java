package com.example.loanportal.loanportalbackend.service;

import com.example.loanportal.loanportalbackend.dto.LoginRequest;
import com.example.loanportal.loanportalbackend.model.Student;
import com.example.loanportal.loanportalbackend.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    // Register a new student
    public Student register(Student student) {
        return studentRepository.save(student);
    }

    // Login using email and password
    public Student login(LoginRequest request) {
        Optional<Student> studentOpt = studentRepository.findByEmail(request.getEmail());
        return studentOpt.filter(s -> s.getPassword().equals(request.getPassword()))
                .orElse(null);
    }

    // Get student details by ID
    public Student getStudent(Long id) {
        return studentRepository.findById(id).orElse(null);
    }
}
