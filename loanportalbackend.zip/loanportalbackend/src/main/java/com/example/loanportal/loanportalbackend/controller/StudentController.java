package com.example.loanportal.loanportalbackend.controller;

import com.example.loanportal.loanportalbackend.model.Student;
import com.example.loanportal.loanportalbackend.dto.LoginRequest;
import com.example.loanportal.loanportalbackend.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/students")
@CrossOrigin("*")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/register")
    public ResponseEntity<Student> register(@RequestBody Student student) {
        return ResponseEntity.ok(studentService.register(student));
    }

    @PostMapping("/login")
    public ResponseEntity<Student> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(studentService.login(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudent(@PathVariable Long id) {
        return ResponseEntity.ok(studentService.getStudent(id));
    }
}
