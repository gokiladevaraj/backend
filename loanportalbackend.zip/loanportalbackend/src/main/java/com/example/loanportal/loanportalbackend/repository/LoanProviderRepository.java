package com.example.loanportal.loanportalbackend.repository;

import com.example.loanportal.loanportalbackend.model.LoanProvider;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoanProviderRepository extends JpaRepository<LoanProvider, Long> {

    // Default JPA methods for CRUD are sufficient
}
