package com.example.loanportal.loanportalbackend.controller;

import com.example.loanportal.loanportalbackend.model.LoanProvider;
import com.example.loanportal.loanportalbackend.service.LoanProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loan-providers")
@CrossOrigin("*")
public class LoanProviderController {

    @Autowired
    private LoanProviderService loanProviderService;

    // Add a new loan provider
    @PostMapping("/add")
    public ResponseEntity<LoanProvider> addProvider(@RequestBody LoanProvider provider) {
        return ResponseEntity.ok(loanProviderService.addProvider(provider));
    }

    // Get all loan providers
    @GetMapping("/all")
    public ResponseEntity<List<LoanProvider>> getAllProviders() {
        return ResponseEntity.ok(loanProviderService.getAllProviders());
    }
}
